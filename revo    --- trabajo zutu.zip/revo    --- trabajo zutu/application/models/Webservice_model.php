<?php

class Webservice_model extends CI_Model{

	public function checarlogin($usuario,$password){
		$this->db->select('*');
		$this->db->from('msicu_usuarios');
		$this->db->where("correo", $usuario);
		$this->db->where("password", md5($password));
		return $this->db->get()->row();
	}

	function checarexistencia($correo){
    	$this->db->select('username,password,nombre,apellido,correo');
    	$this->db->where('correo', $correo); 
    	$this->db->from('msicu_usuarios');
    	return $this->db->count_all_results();
    }

	function guardarusuario($datos){
    	if(!$this->db->insert('msicu_usuarios', $datos)){
            return false;
        }
        return true;
    }

    function checarsivoto($id){
    	$this->db->select('*');
    	$this->db->where('id_usuario_voto', $id); 
    	$this->db->from('msicu_votos');
    	return $this->db->count_all_results();
    }

    function guardaVoto($datos){
    	$this->db->insert('msicu_votos', $datos);
    	return $this->db->insert_id();
    }

    function totales(){
        $this->db->select('valor nombre, count(*) valor');
        $this->db->from('msicu_votos');
        $this->db->group_by('valor');
        return $this->db->get()->result();
    }

}