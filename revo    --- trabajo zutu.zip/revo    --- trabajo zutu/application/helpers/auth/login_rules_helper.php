<?php

function getLoginRules(){
    return array(
    array(
    'field' => 'password',
    'label' => 'Password',
    'rules' => 'required|trim|alpha_dash',
    'errors' => array(
    'required' => 'El %s es requerido',
    'alpha_dash' => 'El %s introducido no es valido',
    ),
    ),// fin password
    array(
    'field' => 'Email',
    'label' => 'Email',
    'rules' => 'required|trim|valid_email',
    'errors' => array(
    'required' => 'El %s es requerido',
    'valid_email' => 'El %s. es invalido',
    ),
    )//fin email
    );//fin array Principal
}//fin getLoginRules

function getRegistroRules(){
    return array(
    array(
    'field' => 'firstName',
    'label' => 'Nombre',
    'rules' => 'required|alpha',
    'errors' => array(
    'required' => 'Por favor ingresa un dato',
    'alpha' => 'El %s introducido no es invalido',
    ),
    ),
    array(
    'field' => 'lastName',
    'label' => 'Apellido',
    'rules' => 'required|alpha',
    'errors' => array(
    'required' => 'Por favor ingresa un dato',
    'alpha' => 'El %s. introducido no es valido',
    ),
    ),
    array(
    'field' => 'password',
    'label' => 'Password',
    'rules' => 'required|alpha_dash',
    'errors' => array(
    'required' => 'Por favor ingresa un dato',
    'alpha_dash' => 'El %s. introducido no es valido',
    ),
    ),
    array(
    'field' => 'password_c',
    'label' => 'Password',
    'rules' => 'required|alpha_dash',
    'errors' => array(
    'required' => 'Por favor ingresa un dato',
    'alpha_dash' => 'El %s. introducido no es valido',
    ),
    ),
    array(
    'field' => 'email',
    'label' => 'Email',
    'rules' => 'required|valid_email',
    'errors' => array(
    'required' => 'Por favor ingresa un dato',
    'valid_email' => 'El %s. es invalido',
    ),
    )
    );//fin array Principal
}//fin getLoginRules


?>