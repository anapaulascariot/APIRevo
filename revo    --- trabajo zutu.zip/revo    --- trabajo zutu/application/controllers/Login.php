<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

    
    public function __construct(){
        parent:: __construct();
        $this->load->model('Webservice_model');
    }
    
	public function index()
	{
        $this->load->view('login');
	}
    
   //servicio web para iniciar sesión
   public function validate(){
        $this->form_validation->set_error_delimiters('', '');//para colocar etiquetas delimitadoras en los errores ejemplo: <div class="error">
        $rules = getLoginRules();
        $this->form_validation->set_rules($rules);
        if($this->form_validation->run() === false){
            $errors=array(
                'email' => form_error('Email'),
                'password' => form_error('password')
            );
            echo json_encode($errors);
            $this->output->set_status_header(400);
        }else{
        $correo= $this->input->post('Email');
        $password= $this->input->post('password');
        $respuesta = array();
        $dato = $this->Webservice_model->checarlogin($correo,$password);
        if (isset($dato)) {
                    $objeto = $dato;
                    $respuesta["datos"] = $objeto;
                    $datosusuario = array(
                        'id' => $objeto->id,
                        'nombre' => $objeto->nombre,
                        'apellido' => $objeto->apellido,
                        'correo' => $objeto->correo,
                        'username' => $objeto->username,
                        'is_logged'=> TRUE
                    );

                    $this->session->set_userdata($datosusuario);
		            $this->session->set_flashdata('msg','Bienvenido al sistema'.$datosusuario['nombre']);
		            echo json_encode(array('url' => base_url('Votacion')));
        }else{
            $respuesta["result"] = "false";
            $respuesta["mensaje"] = 'Credenciales de inicio de sesión inválidas';
            $result="false";
            echo json_encode(array('msg'=> $respuesta["mensaje"] ));
            $this->output->set_status_header(401);
            exit;
        }

    	}
    }
    
    //matar la sesión y variables
    public function logout(){
         $vars = array('id','nombre','apellido','correo','username','is_logged');
         $this->session->unset_userdata($vars);
         $this->session->sess_destroy();
         redirect($this->config->item('base_url').'Login');
    }//fin logout
}
