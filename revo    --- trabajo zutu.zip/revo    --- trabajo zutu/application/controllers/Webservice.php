<?php
 if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Webservice extends CI_Controller{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('Webservice_model');
    }

    //manda el voto del usuario
    public function guardaVotacion(){
        header("Content-Type:application/json");
        header('Access-Control-Allow-Origin: *');

         $id_usuario = $this->session->userdata("id");
         $valor = $this->input->post("valor_de_voto");

	     $datos = array(
	       'id_usuario_voto' =>  $id_usuario, 
	       'valor' =>  $valor
	     );

         $existe = $this->Webservice_model->checarsivoto($id_usuario);
         if($existe > 0){
            $data['estatus']     = 'ERROR';
            $data['mensaje']     = 'Ya has votado anteriormente';
         }else{
             $data['estatus']     = 'OK';
             $data['mensaje']     = 'Voto registrado correctamente';
             $dato = $this->Webservice_model->guardaVoto($datos);
             if ($dato) {
                    echo json_encode(["pasa" => true]);
                }else{
                    echo json_encode(["pasa" => false]);
                }
         }
        //echo json_encode($data);
    }

    //obtiene los datos por post para pintar las gráficas
    public function datosGraficas(){
        if ($this->input->is_ajax_request()) {
            header('Content-Type: application/json');
            $datos["registrodevotos"] = $this->Webservice_model->totales();
            echo json_encode($datos);
        }else{
            redirect('Login');
        }
    }


} /*cierre de controller*/

