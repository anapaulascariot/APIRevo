<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Registro extends CI_Controller {

    public function __construct(){
        parent:: __construct();
        $this->load->model('Webservice_model');
    }//fin constructor()
    
	public function index()
	{
		$this->load->view('registro');        
	}//fin index()
    
    public function create(){
    $username = $this->input->post('firstName');
    $lastname = $this->input->post('lastName');
    $email = $this->input->post('email');
    $password = $this->input->post('password');
    $password_c = $this->input->post('password_c');
    $nombreusuario = $this->input->post('username');

    $config = array(
    array(
    'field' => 'firstName',
    'label' => 'firstName',
    'rules' => 'required|alpha',
    'errors' => array(
    'required' => 'Por favor, ingresa un dato ',
    'alpha' => 'El valor introducido no es válido ',
    ),
    ),
    array(
    'field' => 'lastName',
    'label' => 'lastName',
    'rules' => 'required|alpha',
    'errors' => array(
    'required' => 'Por favor, ingresa un dato',
    'alpha' => 'El valor introducido no es válido ',
    ),
    ),
    array(
    'field' => 'password',
    'label' => 'Password',
    'rules' => 'required|alpha_dash',
    'errors' => array(
    'required' => 'Por favor, ingresa un dato ',
    'alpha_dash' => 'El %s introducido no es válido ',
    ),
    ),
    array(
    'field' => 'password_c',
    'label' => 'password_c',
    'rules' => 'required|alpha_dash',
    'errors' => array(
    'required' => 'Por favor, ingresa un dato ',
    'alpha_dash' => 'El password introducido no es válido ',
    ),
    ),
    array(
    'field' => 'username',
    'label' => 'username',
    'rules' => 'required|alpha_dash',
    'errors' => array(
    'required' => 'Por favor, ingresa un dato ',
    'alpha_dash' => 'El password introducido no es válido ',
    ),
    ),
    array(
    'field' => 'email',
    'label' => 'Email',
    'rules' => 'required|valid_email',
    'errors' => array(
    'required' => 'Por favor, ingresa un dato',
    'alpha_dash' => 'El nombre de usuario no es válido',
    ),
    )
    );
$this->form_validation->set_rules($config);
         if ($this->form_validation->run() === false)
                {
             $errors=array(
                'firstName' => form_error('firstName'),
                'lastName' => form_error('lastName'),
                'email' => form_error('Email'),
                'password' => form_error('password'),
                'password_c' => form_error('password_c'),
                'username' => form_error('username')
            );
              echo json_encode($errors);
              $this->output->set_status_header(402);
               exit;
                }//fin true
                else
                {
                  $datos = array(
                  'nombre'=> $username,
                  'apellido'=>$lastname,
                  'correo'=>$email,
                  'password'=>$password,
                  'username' => $nombreusuario,
                  'hora_registro' => date("H:i:s"),
                  'fecha_registro' => date("Y-m-d")
                   );//fin array

          $existe = $this->Webservice_model->checarexistencia($email);
          if($existe > 0){
                $this->output->set_status_header(401);
                echo json_encode(array('msg'=> 'El correo de usuario ya está registrado'));
                exit;
          }else{

            if(!$this->Webservice_model->guardarusuario($datos)){
                $this->output->set_status_header(401);
                echo json_encode(array('msg'=> 'Usuario no registrado, intente más tarde por favor'));
                exit;
            }//fin if create
             echo json_encode(array('msg'=> 'Usuario registrado con éxito'));  
            }//fin else

          } //fin else existencia
    
    }//fin create()



    
}//fin clase
