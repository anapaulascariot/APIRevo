<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Votacion extends CI_Controller {
    
    public function __construct(){
        parent::__construct();
    }//fin constructor
    
    public function index(){
        if($this->session->userdata('is_logged')){
            $this->load->view('votos');
        }else{
            show_404();
        }
        
    }//fin index
    
}
    ?>