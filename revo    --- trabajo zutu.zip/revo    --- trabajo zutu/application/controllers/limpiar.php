
<?php

function Limpiartexto($s) {
		//$s = mb_convert_encoding($s, 'UTF-8','');
		$s = preg_replace("/à|â|ã|ª/","a",$s);
		$s = preg_replace("/À|Â|Ã/","A",$s);
		$s = preg_replace("/è|ê/","e",$s);
		$s = preg_replace("/È|Ê/","E",$s);
		$s = preg_replace("/ì|î/","i",$s);
		$s = preg_replace("/Ì|Î/","I",$s);
		$s = preg_replace("/ò|ô|õ|º/","o",$s);
		$s = preg_replace("/Ò|Ô|Õ/","O",$s);
		$s = preg_replace("/ù|û/","u",$s);
		$s = preg_replace("/Ù|Û/","U",$s);
		//$s = str_replace(" ","_",$s);
		//$s = str_replace("ñ","n",$s);
		//$s = str_replace("Ñ","N",$s);
        //$s = preg_replace('/[^a-zA-Z0-9_.-]/', '', $s);
		$s = preg_replace('/[^a-zA-Z ]/', '', $s);
		return $s;
	}

function Limpiartexto2($s) {
		//$s = mb_convert_encoding($s, 'UTF-8','');
		$s = preg_replace("/à|â|ã|ª/","a",$s);
		$s = preg_replace("/À|Â|Ã/","A",$s);
		$s = preg_replace("/è|ê/","e",$s);
		$s = preg_replace("/È|Ê/","E",$s);
		$s = preg_replace("/ì|î/","i",$s);
		$s = preg_replace("/Ì|Î/","I",$s);
		$s = preg_replace("/ò|ô|õ|º/","o",$s);
		$s = preg_replace("/Ò|Ô|Õ/","O",$s);
		$s = preg_replace("/ù|û/","u",$s);
		$s = preg_replace("/Ù|Û/","U",$s);
		$s = str_replace(" ","_",$s);
		//$s = str_replace("ñ","n",$s);
		//$s = str_replace("Ñ","N",$s);
        $s = preg_replace('/[^a-zA-Z0-9_.-]/', '', $s);
		return $s;
	}

function Limpiarcorreo($s) {
		//$s = mb_convert_encoding($s, 'UTF-8','');
		$s = preg_replace("/à|â|ã|ª/","a",$s);
		$s = preg_replace("/À|Â|Ã/","A",$s);
		$s = preg_replace("/è|ê/","e",$s);
		$s = preg_replace("/È|Ê/","E",$s);
		$s = preg_replace("/ì|î/","i",$s);
		$s = preg_replace("/Ì|Î/","I",$s);
		$s = preg_replace("/ò|ô|õ|º/","o",$s);
		$s = preg_replace("/Ò|Ô|Õ/","O",$s);
		$s = preg_replace("/ù|û/","u",$s);
		$s = preg_replace("/Ù|Û/","U",$s);
		$s = str_replace(" ","_",$s);
		//$s = str_replace("ñ","n",$s);
		//$s = str_replace("Ñ","N",$s);
        $s = preg_replace('/[^a-zA-Z0-9_.@-]/', '', $s);
		return $s;
	}

function Limpiarbusqueda($s) {
		//$s = mb_convert_encoding($s, 'UTF-8','');
		$s = preg_replace("/à|â|ã|ª/","a",$s);
		$s = preg_replace("/À|Â|Ã/","A",$s);
		$s = preg_replace("/è|ê/","e",$s);
		$s = preg_replace("/È|Ê/","E",$s);
		$s = preg_replace("/ì|î/","i",$s);
		$s = preg_replace("/Ì|Î/","I",$s);
		$s = preg_replace("/ò|ô|õ|º/","o",$s);
		$s = preg_replace("/Ò|Ô|Õ/","O",$s);
		$s = preg_replace("/ù|û/","u",$s);
		$s = preg_replace("/Ù|Û/","U",$s);
		//$s = str_replace(" ","_",$s);
		//$s = str_replace("ñ","n",$s);
		//$s = str_replace("Ñ","N",$s);
        $s = preg_replace('/[^a-zA-Z0-9_.@-]/', '', $s);
		return $s;
	}

function Limpiarnumeros($s) {
            $s = str_replace(" ",'',$s);
        	$s = preg_replace('/[^0-9]/', '', $s);
    return $s;
	}

function Limpiarfecha($s) {
            $s = str_replace(" ",'',$s);
        	$s = preg_replace('/[^0-9:-]/', '', $s);
    return $s;
	}
?>
