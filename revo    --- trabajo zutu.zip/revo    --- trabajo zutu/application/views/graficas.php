<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Gráficas de votos</title>
	<style type="text/css">
		#graficaVotos {width: 80% !important; height: 80% !important; }
	</style>
    <!-- Bootstrap core CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <!-- styles -->
    <link href="./assets/css/dashboard.css" rel="stylesheet">
    <link href="./assets/bootstrap_4.3.1/css/bootstrap.css" rel="stylesheet" type="text/css"> 
    <link href="./assets/css/votos.css" rel="stylesheet" type="text/css"> 
</head>
<body>
   <nav class="navbar navbar-dark fixed-top bg-dark flex-md-nowrap p-0 shadow">
  <a class="navbar-brand col-sm-3 col-md-2 mr-0" href="#"><?=$this->session->userdata('nombre').' '.$this->session->userdata('apellido');?></a>
  <ul class="navbar-nav px-3">
    <li class="nav-item text-nowrap">
      <a class="nav-link" href="<?= base_url('login/logout')?>">Cerrar sesión</a>
    </li>
  </ul>
</nav>
<div id="container">
	<h1 style="margin-top: 45px">Frecuencia de votos</h1>
	<div id="body">
		<div>
			<h1 id="textoRegistrados"></h1>
			<canvas id="graficaVotos"></canvas>
		</div>
	</div>

</div>
<script type="text/javascript" src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
<script src="<?php echo $this->config->item('base_url')?>/assets/js/Chart.min.js"></script>
<script src="<?php echo $this->config->item('base_url')?>/assets/js/graficas.js"></script>

</body>
</html>