<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="Equipo 4" content="xalapa, MSICU">
    <title>Sistema e Votos</title>

    <!-- Bootstrap CSS-->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" >
    <link href="./assets/bootstrap_4.3.1/css/bootstrap.css" rel="stylesheet" type="text/css">
    <!-- Css de la vista -->
    <link href="./assets/css/login.css" rel="stylesheet" type="text/css">
    
    
  </head>
  <body class="text-center">
<!--?=php var_dump($menu)?> http://localhost/revo/index.php/Login/validate -->   

<div class="container" style="margin-top:4em">

<form class="form-signin" action="<?= base_url('index.php/login/validate/'); ?>" id="frm_login" method="POST">
 <img class="mb-4" src="./assets/iconos/002-dinosaur.png" alt="" width="72" height="72">
  <h1 class="h3 mb-3 font-weight-normal" id="banner">¡Hola! Bienvenido al sistema de votos</h1>
  <div class="form-group" id="alerta">
   
    </div>
  <div class="form-group" id="email">
    <label for="exampleInputEmail1">Email address</label>
    <input type="email" class="form-control" id="inputEmail" name="Email" class="form-control" placeholder="Email address"  autofocus aria-describedby="emailHelp">
     <div class="invalid-feedback">
       
    </div>
    
  </div>
  <div class="form-group" id="password">
    <label for="exampleInputPassword1">Password</label>
    <input type="password" class="form-control " id="exampleInputPassword1" placeholder="Password" name="password">
    <div class="invalid-feedback">
   
    </div>
  </div>
  <button type="submit" class="btn btn-primary">Iniciar sesión</button>
  
</form>
<a href="registro">Registrarse</a>
</div>
</body>

<script type="text/javascript" src="./assets/js/jquery-3-3-1.min.js"></script>
<script type="text/javascript" src="./assets/js/auth/login.js"></script>
<script src="./assets/bootstrap_4.3.1/js/bootstrap.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" ></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" ></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" ></script>
</html>