<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="es-MX">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <title>Registro</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link href="./assets/bootstrap_4.3.1/css/bootstrap.css" rel="stylesheet" type="text/css"> 
    <link href="./assets/css/registro.css" rel="stylesheet" type="text/css"> 
</head>
    <style>
    .formulario{
        position :relative !important; 
        left: 25% !important;
        padding-top: 40px;
    }
    body{background-color: #f5f5f5}
    </style>
    
    
<body class="text-center col-xs-12">
    <!------------------------Registro-- AGREGAR NAME A TODOS-------------------------------->
    <div class="col-md-6 order-md-2 center-block formulario">
        <h4 class="mb-3">Registro de usuario</h4>
        

        <form action="index.php/Registro/create" method="post" id="Registro">
           <div class=" form-group mb-3" id="alerta">
                   
                </div>
            <div class="row">
                
                <div id="nombre" class="col-md-6 mb-3">
                    <label for="firstName">Nombre: </label>
                    <input type="text" class="form-control" id="firstName" name="firstName" placeholder="" required>
                    <div class="invalid-feedback">
                        
                    </div>
                </div>
                <div id="apellido" class="col-md-6 mb-3">
                    <label for="lastName">Apellido: </label>
                    <input type="text" class="form-control" name="lastName" id="lastName" placeholder="" value="" required>
                    <div class="invalid-feedback">
                        
                    </div>
                </div>
            </div>


            <div id="email" class="mb-3">
                <label for="email">Correo: </label>
                <input type="email" class="form-control" id="email" name="email" placeholder="correo@sitio.com">
                <div class="invalid-feedback">
                    
                </div>
            </div>

            <div id="username" class="mb-3">
                <label for="username">Nombre de usuario: </label>
                <input type="text" class="form-control" id="username" name="username">
                <div class="invalid-feedback">
                    
                </div>
            </div>

            <div id="password" class="mb-3">
                <label for="password">Contraseña: </label>
                <input type="password" class="form-control" name="password" id="password">
                <div class="invalid-feedback">
                    
                </div>
            </div>
            <div id="password_c" class="mb-3">
                <label for="password2">Confirmar Contraseña: </label>
                <input type="password2" class="form-control" id="password_c" name="password_c">
                <div class="invalid-feedback">
                    
                </div>
            </div>
            <div class="mb-3">
                <button id="btnRegistrar" class="btn btn-lg btn-primary btn-block" type="submit">Registrarse</button>
                
            </div>
            <a href="login" class="btn btn-info btn-lg btn-block active" role="button" aria-pressed="true">Volver</a>
        </form>
        
    </div>
    <!------------------------Registro---------------------------------->
</body>


<script type="text/javascript" src="./assets/js/jquery-3-3-1.min.js"></script>
<script src="./assets/bootstrap_4.3.1/js/bootstrap.js"></script>
<script type="text/javascript" src="./assets/js/auth/login.js"></script>
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" ></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" ></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</html>