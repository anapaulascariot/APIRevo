<!doctype html>
<html lang="es-MX">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <title>Sistema de votos</title>

    <!-- Bootstrap core CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <!-- styles -->
    <link href="./assets/css/dashboard.css" rel="stylesheet">
    <link href="./assets/bootstrap_4.3.1/css/bootstrap.css" rel="stylesheet" type="text/css"> 
    <link href="./assets/css/votos.css" rel="stylesheet" type="text/css"> 

  </head>
   <nav class="navbar navbar-dark fixed-top bg-dark flex-md-nowrap p-0 shadow">
  <a class="navbar-brand col-sm-3 col-md-2 mr-0" href="#"><?=$this->session->userdata('nombre').' '.$this->session->userdata('apellido');?></a>
  <ul class="navbar-nav px-3">
    <li class="nav-item text-nowrap">
      <a class="nav-link" href="<?= base_url('login/logout')?>">Cerrar sesión</a>
    </li>
  </ul>
</nav>
  <body>
   
<container>
    
    <?php if($mensaje= $this->session->flashdata('msg')):?>
    <p><?=$mensaje?></p>
    <?php endif;  ?>


    <div class="row">
      <div class="card" align="center">
        <div class="card-header bg-primary text-white">Sistema de voto</div>
        <div class="card-body">
          <strong>¿Qué calificación le daría al presidente?<strong><br>
            <p>En dónde 5 es excelente y 1 representa un pésimo servicio.</p>
            <div class="form-check">
              <label class="form-check-label" for="radio1">
                <input type="radio" class="form-check-input" id="radio1" name="optradio" value="1">Calificación de 1
              </label>
            </div>
            <div class="form-check">
              <label class="form-check-label" for="radio2">
                <input type="radio" class="form-check-input" id="radio2" name="optradio" value="2">Calificación de 2
              </label>
            </div>
            <div class="form-check">
              <label class="form-check-label" for="radio2">
                <input type="radio" class="form-check-input" id="radio3" name="optradio" value="3">Calificación de 3
              </label>
            </div>
            <div class="form-check">
              <label class="form-check-label" for="radio2">
                <input type="radio" class="form-check-input" id="radio4" name="optradio" value="4">Calificación de 4
              </label>
            </div>
            <div class="form-check">
              <label class="form-check-label" for="radio2">
                <input type="radio" class="form-check-input" id="radio5" name="optradio" value="5">Calificación de 5
              </label>
            </div>
        </div>

        <div class="card-footer"><button class="btn btn-primary" id="enviarVoto">Enviar calificación</button></div>
      </div>
    </div>

    <!-- modal para verificar botón elegido -->
    <div class="modal" id="miModalVacioBoton">
      <div class="modal-dialog">
        <div class="modal-content">
          <!-- Modal Header -->
          <div class="modal-header bg-danger text-white">
            <h4 class="modal-title">¡Advertencia!</h4>
          </div>
          <!-- Modal body -->
          <div class="modal-body">
            Debes elegir un valor para la votación
          </div>
          <!-- Modal footer -->
          <div class="modal-footer">
            <button type="button" class="btn btn-danger" id="cerrar1" data-dismiss="modal">Cerrar</button>
          </div>
        </div>
      </div>
    </div>

<div id="modalOK" class="modal fade" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header bg-primary text-white">
        <h5 class="modal-title">Información</h5>
      </div>
      <div class="modal-body">
        <h4>Datos guardados correctamente</h4>
      </div>
      <div class="modal-footer">
        <button id="cerrar2" type="button" class="btn btn-danger" data-dismiss="modal">Ir a ver las gráficas de voto</button>
      </div>
    </div>
  </div>
</div>

<div id="modalError" class="modal fade" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header bg-danger text-white">
        <h5 class="modal-title">Información</h5>
      </div>
      <div class="modal-body">
        <h4>No ha sido posible guardar tu voto o ya ha votado antes</h4>
      </div>
      <div class="modal-footer">
        <button id="cerrar3" type="button" class="btn btn-danger" data-dismiss="modal">Cerrar</button>
      </div>
    </div>
  </div>
</div>

</container>
</body>

<script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" ></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" ></script>

<script type="text/javascript">
      $(document).ready(function(){
        $("#enviarVoto").click(function(){
            var radioValue = $("input[name='optradio']:checked").val();
            if(radioValue){
                $.ajax({
                  url: 'index.php/Webservice/guardaVotacion',
                  type: 'post',
                  dataType: 'json',
                  data: {'valor_de_voto': radioValue},
                })
                .done(function(data) {
                  if (data.pasa) {
                    $('#modalConfirma').modal('hide');
                    $('#modalOK').modal();
                  }else{
                    $('#modalConfirma').modal('hide');
                    $('#modalError').modal();
                  }
                })
                .fail(function() {
                  $('#modalConfirma').modal('hide');
                  $('#modalError').modal();
                });
            }else{
                $('#miModalVacioBoton').show();
            }
        });

        $("#cerrar1").click(function(){
              $("#miModalVacioBoton").hide();
        });

        $("#cerrar2").click(function(){
              $("#modalOK").hide();
              window.location.replace("index.php/Graficas");
        });

        $("#cerrar1").click(function(){
              $("#modalError").hide();
        });

    });
</script>

</html>