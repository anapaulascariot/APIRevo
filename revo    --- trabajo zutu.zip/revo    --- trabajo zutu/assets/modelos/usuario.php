<?php

    class usuario{
         private $conexion;
        
        public function __construct()
        {
            require_once('conexion.php');
            $this->conexion= new conexion();
            $this->conexion->conectar();
            
        }
        
        function identificar($usuario,$password)
        {
            $sql="SELECT * FROM usuario WHERE correo='".$usuario."' AND contraseña='".$password."'";
            $resultados= $this->conexion->conexion->query($sql);
            if($resultados->num_rows>0){
                $r=$resultados->fetch_array();
                
            }
            else{
                $r[0]=0;
            }
            return $r;
            $this->conexion->cerrar();
        }//fin identificar
        
          function lista_usuarios($valor)
        {
            $sql="SELECT * FROM usuarios WHERE nombre_usuario LIKE '%".$valor."%' OR email_usuario LIKE '%".$valor."%'";
            $this->conexion->conexion->set_charset('utf8');
            $resultados=$this->conexion->conexion->query($sql);
            $arreglo = array();
            while ($re=$resultados->fetch_array(MYSQLI_NUM)){
                $arreglo[]=$re;
            }//fin while
            return $arreglo;
            $this->conexion->cerrar();
        }//fin lista_usuario()
        
        function actualizar_usuario($id,$nombre,$telefono,$email,$password){
            $sql="UPDATE usuarios SET nombre_usuario ='".$nombre."' ,telefono_usuario='".$telefono."',email_usuario ='".$email."',password_usuario ='".$password."'WHERE id_usuario= '".$id."'";
            if($this->conexion->conexion->query($sql)){
             return true;   
            }else{
                return false;
            }
            $this->conexion->cerrar();             
        }//fin actualizar_usuario()
        
        function eliminar_usuario($id){
            $sql="DELETE FROM usuarios WHERE id_usuario= '".$id."'";
            if($this->conexion->conexion->query($sql)){
             return true;   
            }else{
                return false;
            }
            $this->conexion->cerrar();    
        }//fin eliminar_usuario()
        
        function agregar_usuario($nombre,$telefono,$email,$password){
            $sql="INSERT INTO usuarios (id_usuario,nombre_usuario,telefono_usuario,email_usuario,password_usuario) VALUES ( NULL,'".$nombre."','".$telefono."','".$email."','".$password."')";
            if($this->conexion->conexion->query($sql)){
             return true;   
            }else{
                return false;
            }
            $this->conexion->cerrar();    
        }//fin eliminar_usuario()
        
    }//class usuario
    //prueba para verificar que si se establece la conexion;
    //$ins = new usuario();
    //if($ins->agregar_usuario('prueba5','2289888642','prueba@gmail.com','prueba1234')){
      //  echo 'se actualizo';
    //}else{
    //  echo 'algo ocurrio falle :(';
    //}
    //$array=$ins->identificar('sfigu@outlook.com','gato123');
    //echo $array[3];
?>