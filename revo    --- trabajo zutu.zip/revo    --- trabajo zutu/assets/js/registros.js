$(document).ready(function () {
   //alert("Vinvulación completa");
});//fin document.ready

$('#btnsesion').click(function(){
       var dataString = 'boton=cerrar';
        $.ajax({
            url: '../../cocina/conexion/controladores/usuario.php',
            type: "POST",
            data: dataString,
            async: false,
            success: function (respuesta) {
                location.href = '../../vistas/login.html';
            }
        });
    });
    
 $('#btnlogin2').click(function(){
     alert("holi :3");
 });

 $('#btnlogin').click(function(){
        var usuario = $('#inputEmail').val();
        var password = $('#inputPassword').val();
        var dataString = 'usuario=' + usuario + '&password=' + password + '&boton=ingresar';
        alert(dataString);
        $.ajax({
            url: '../../../application/controllers/usuario.php',
            type: "POST",
            data: dataString,
            async: false,
            
        }).done(function(resp){
            alert(resp);
        }); 
     return false;
    });
    



function lista_usuarios(valor){
       var dataString = 'valor=' + valor + '&boton=buscar';
        $.ajax({
				type:"POST",
				url:"../../cocina/conexion/controladores/usuario.php",
				data:dataString,
				success:function(r){
					//alert(r);
                    var valores= eval(r);
                    //alert(valores instanceof Array);
                    html="<table class='table dataTable'><thead><tr><th>#</th><th>Nombre</th><th>Telefono</th><th>Email</th><th>Pasword</th><th>Editar</th><th>Eliminar</th></tr></thead><tbody>";
                    for(i=0;i<valores.length;i++){
                        datos=valores[i][0]+"*"+valores[i][1]+"*"+valores[i][2]+"*"+valores[i][3]+"*"+valores[i][4];
                        //var datos="hola";
                        html+="<tr><td id='"+valores[i][0]+"'>"+valores[i][0]+"</td><td>"+valores[i][1]+"</td><td>"+valores[i][2]+"</td><td>"+valores[i][3]+"</td><td>"+valores[i][4]+"</td><td>"+"<button type='button' class=' btn btnmodal btn-warning' data-toggle='modal' data-target='#exampleModal' onclick='mostrar("+'"'+datos+'"'+");'><span class='icon-pencil iconospan'></span></button>"+"</td><td>"+"<button type='button' class=' btn btnmodal btn-danger' onclick='eliminar("+'"'+valores[i][0]+'"'+");'><span class='icon-trash iconospan'></button>"+"</td></tr>";
                    }
                    html+="</tbody></table>";
                    $("#listausuarios").html(html);
				}
			});// fin ajax me quede en el minuto24:01 / 37:59 https://www.youtube.com/watch?v=2EHUE1duRLc
    }//fin lista usuarios

function ocultarestado(){
    $( "#exito" ).hide(10);
}

function actualizar_usuario(){
    var datosform=$("#formactualizar").serialize();
    var dataString = datosform + '&boton=actualizar';
    //alert(dataString);
    $.ajax({
				type:"POST",
				url:"../../cocina/conexion/controladores/usuario.php",
				data:dataString,
				success:function(r){
					if(r==1){
                        $("#exito").show();
                    }else{
                         alert(r);  
                    }
                   
				}
    });// fin ajax
    lista_usuarios('');
        
}// fin actualizar

function registrar_usuario(){
    ocultarestado2();
    var datosform=$("#registrousuario").serialize();
    var dataString = datosform + '&boton=registrar';
   $.ajax({
				type:"POST",
				url:"../../cocina/conexion/controladores/usuario.php",
				data:dataString,
				success:function(r){
					if(r==1){
                        $("#exito2").show();
                    }else{
                         alert(r);  
                    }
                   
				}
    });// fin ajax
    lista_usuarios('');
    limpiar_registro();
}//fin registrar

function limpiar_registro(){
    $("#txtnombrer").val("");
    $("#txttelefonor").val("");
    $("#txtemailr").val("");
    $("#txtpasswordr").val("");
}

function ocultarestado2(){
    $( "#exito2" ).hide(10);
}

function mostrar(datos){
    //alert(datos);
    var d=datos.split("*");
    //alert(d.length);
    $("#idusuario").val(d[0]);
    $("#txtnombre").val(d[1]);
    $("#txttelefono").val(d[2]);
    $("#txtemail").val(d[3]);
    $("#txtpassword").val(d[4]);
}

    
    /* =============================================================================
   Responsive Table CSS
   ========================================================================== */