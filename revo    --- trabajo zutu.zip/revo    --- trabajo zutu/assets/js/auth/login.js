$(document).ready(function () {
 // alert("Vinvulación completa");
});//fin document.ready

(function($){
    $("#frm_login").submit(function(ev){
        ev.preventDefault();
        $("#alerta").html("");
        $.ajax({
           url: 'login/validate',
           type: 'POST',
           data: $(this).serialize(),
           success: function(data){
               $("#email > input").removeClass('is-invalid');
               $("#password > input").removeClass('is-invalid');
              var datosjson = JSON.parse(data);
               console.log(datosjson);
               window.location.replace(datosjson.url);
               
           },
            statusCode: {
               400: function(xhr){
                    $("#email > input").removeClass('is-invalid');
                   $("#password > input").removeClass('is-invalid');
                   var jasonerror= JSON.parse(xhr.responseText);
                    //console.log(jasonerror);
                    if(jasonerror.email.length !=0){
                        console.log(xhr.status);
                        $("#email > div").html(jasonerror.email);
                        $("#email > input").addClass('is-invalid');
                    }//fin if email
                    if(jasonerror.password.length !=0){
                        console.log(xhr.status);
                        $("#password > div").html(jasonerror.password);
                        $("#password > input").addClass('is-invalid');
                    }//fin if password
               },
                401: function(xhr){
                     console.log(xhr.status);
                    $("#email > input").addClass('is-invalid');
                    $("#password > input").addClass('is-invalid');
                    var jasonerror= JSON.parse(xhr.responseText);
                    console.log(jasonerror.msg);
                    //$("#banner").text(jasonerror.msg);
                    $("#alerta").html('<div class="alert alert-danger"role="alert">'+jasonerror.msg+'</div>')
                }
            }//fin errores,
        });//fin ajax
    });//fin ev
    
     $("#Registro").submit(function(ev){
        ev.preventDefault();
        $("#alerta").html("");
        $.ajax({
           url: 'Registro/create',
           type: 'POST',
           data: $(this).serialize(),
           success: function(data){
               $("#email > input").removeClass('is-invalid');
               $("#nombre > input").removeClass('is-invalid');
               $("#apellido > input").removeClass('is-invalid');
               $("#password > input").removeClass('is-invalid');
               $("#password_c > input").removeClass('is-invalid');
               $('#Registro')[0].reset();  
               $("#alertamsg").remove();
              var datosjson = JSON.parse(data);
               console.log(datosjson);
               //$("#firstName").text("");
               $("#alerta").html('<div id="alertamsg" class="alert alert-success" role="alert">'+datosjson.msg+'</div>');
               
           },
            statusCode: {
               402: function(xhr){
                   $("#email > input").removeClass('is-invalid');
                   $("#nombre > input").removeClass('is-invalid');
                   $("#apellido > input").removeClass('is-invalid');
                   $("#password > input").removeClass('is-invalid');
                   $("#password_c > input").removeClass('is-invalid');
                  
                   var jasonerror= JSON.parse(xhr.responseText);
                      if(jasonerror.email.length !=0){
                        console.log(xhr.status);
                        $("#email > div").html(jasonerror.email);
                        $("#email > input").addClass('is-invalid');
                    }//fin if email
                   if(jasonerror.firstName.length !=0){
                        console.log(xhr.status);
                        $("#nombre > div").html(jasonerror.firstName);
                        $("#nombre > input").addClass('is-invalid');
                    }//fin if nombre
                     if(jasonerror.lastName.length !=0){
                        console.log(xhr.status);
                        $("#apellido > div").html(jasonerror.lastName);
                        $("#apellido > input").addClass('is-invalid');
                    }//fin if apellido
                   if(jasonerror.password.length !=0){
                        console.log(xhr.status);
                        $("#password > div").html(jasonerror.password);
                        $("#password > input").addClass('is-invalid');
                    }//fin if password
                   if(jasonerror.password_c.length !=0){
                        console.log(xhr.status);
                        $("#password_c> div").html(jasonerror.password_c);
                        $("#password_c> input").addClass('is-invalid');
                    }//fin if password_c
                  
                   
               },//fin402
                401: function(xhr){
                     $("#email > input").removeClass('is-invalid');
                     $("#nombre > input").removeClass('is-invalid');
                     $("#apellido > input").removeClass('is-invalid');
                     $("#password > input").removeClass('is-invalid');
                     $("#password_c > input").removeClass('is-invalid');
                    console.log(xhr.status);
                    var jasonerror= JSON.parse(xhr.responseText);
                    console.log(jasonerror.msg);
                    //$("#banner").text(jasonerror.msg);
                    $("#alerta").html('<div id="alertamsg" class="alert alert-danger"role="alert">'+jasonerror.msg+'</div>');
                }//fin 401;
            }//fin errores,
        });//fin ajax
    });//fin ev

})(jQuery)
